import logging
import datetime
import tornado

from lib.base import BaseWebSocketHandler, BaseHandler

class MessageHandler(BaseWebSocketHandler):

    def open(self):
        userKey = self.get_argument("userid", "") # 建立连接后添加用户到容器中
        print(userKey)
        result = self.check_user(userKey)
        if result and userKey not in self.application._userOnlineStatusDicts:
            self.application._userOnlineStatusDicts[userKey] = self
            self.update_user_online_status(userKey, 1)
            self._rsdb.lpush("message_user_push_007", '{"userid":"%s"}'%userKey)
            #self.notice_process_msg(userKey, "login")
        elif not result:
            self.close()
        #else:
            #self.close()
    
    def on_message(self, message):
        userKey = self.get_argument("userid", "")
        #print(message)
        logging.debug("on_message[%s]-[%s]-%s" % (self.request.remote_ip, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), message))
        if userKey in self.application._userOnlineStatusDicts:
            self.application._userOnlineStatusDicts[userKey].write_message(message)

    def on_close(self):
        userKey = self.get_argument("userid", "")
        if userKey in self.application._userOnlineStatusDicts:
            self.application._userOnlineStatusDicts.pop(userKey)
            self.update_user_online_status(userKey, 0)
            #self.notice_process_msg(userKey, "logout")
        logging.debug(userKey)

    def check_origin(self, origin):
        return True  # 允许WebSocket的跨域请求
    
    #----------------------------------------------------------------------
    def check_user(self, userkey):
        """检查用户是否存在"""
        tableName = "msg_users"
        keyList = ["userid"]
        kwargs = {
            "where" : [("userid", userkey, "=", "and"),("status", 1, "=", "")]
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        logging.debug(sql)
        result = self._mdb.get(sql)
        if result:
            return True
        else:
            return False
        
    #----------------------------------------------------------------------
    def update_user_online_status(self, userkey, online):
        """更新用户状态"""
        tableName = "msg_users_online_log"
        keyDict = {
            "online" : online
        }
        kwargs = {
            "where" : [("userid", userkey, "=", "")]
        }
        sql = self._sql._update(tableName, keyDict, **kwargs)
        logging.debug(sql)
        self._mdb.execute(sql)
        
        
        
class DisconnectHandler(BaseHandler):

    def get(self):
        """
        """
        result = {
            "code": 1,
            "msg": "断开成功"
        }
        userid = self._xss(self.get_argument("userid", ""))
        if not userid:
            result["code"] = 0
            result["msg"] = "参数不能为空"
        elif not self.check_user(userid):
            result["code"] = 0
            result["msg"] = "用户未在线"
        else:
            self.application._userOnlineStatusDicts[userid].close()
            self.application._userOnlineStatusDicts.pop(userid)
            self.update_user_online_status(userid, 0)
        self.write(result)
        self.finish()
        return
    
    #----------------------------------------------------------------------
    def check_user(self, userkey):
        """检查用户是否存在"""
        tableName = "msg_users"
        keyList = ["userid"]
        kwargs = {
            "where" : [("userid", userkey, "=", "and"),("status", 1, "=", "")]
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        logging.debug(sql)
        result = self._mdb.get(sql)
        if result:
            return True
        else:
            return False
        
    def update_user_online_status(self, userkey, online):
        """更新用户状态"""
        tableName = "msg_users_online_log"
        keyDict = {
            "online" : online
        }
        kwargs = {
            "where" : [("userid", userkey, "=", "")]
        }
        sql = self._sql._update(tableName, keyDict, **kwargs)
        logging.debug(sql)
        self._mdb.execute(sql)