#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 消息推送
  Created: 10/17/18
"""
import logging
import datetime
import json
import traceback

from lib.base import BaseHandler

class MsgUserpush(BaseHandler):
    """
    单用户单条消息推送
    """
    def post(self):
        """
        """
        result = {
            "code": 1,
            "msg": "推送成功"
        }
        userid = self._xss(self.get_argument("userid", ""))
        message = self._xss(self.get_argument("message", ""))
        textType = self._xss(self.get_argument("type", "text"))
        if not userid or not message:
            result["code"] = 0
            result["msg"] = "参数不能为空"
        elif userid not in self.application._userOnlineStatusDicts:
            result["code"] = 4010
            result["msg"] = "用户不在线"
        else:
            logging.info(message)
            if textType == "text":
                self.application._userOnlineStatusDicts[userid].write_message(message)
            elif textType == "json":
                messageJson = json.loads(message)
                self.application._userOnlineStatusDicts[userid].write_message(messageJson)
                if messageJson.get("inid","") and messageJson.get("type","") != "all":
                    self.updateUserMessage(userid, messageJson.get("inid"))
            else:
                logging.debug("message is [%s], type is [%s]." % (message, textType))
        self.write(result)
        self.finish()
        return
    
class MsgUserpushList(BaseHandler):
    """
    单用户多消息推送
    """
    def post(self):
        """
        """
        result = {
            "code": 1,
            "msg": "推送成功"
        }
        userid = self._xss(self.get_argument("userid", ""))
        message = self._xss(self.get_argument("message", ""))
        if not userid or not message:
            result["code"] = 0
            result["msg"] = "参数不能为空"
        elif userid not in self.application._userOnlineStatusDicts:
            result["code"] = 4010
            result["msg"] = "用户不在线"
        else:
            logging.info(message)
            try:
                messageJson = json.loads(message)
                dataList = messageJson.get("dataList",[])
                for data in dataList:
                    self.application._userOnlineStatusDicts[userid].write_message(data)
                    if data.get("inid",""):
                        self.updateUserMessage(userid, data.get("inid"))                    
            except:
                logging.error(traceback.format_exc())
        self.write(result)
        self.finish()
        return
    
class GroupMsgUserpush(BaseHandler):
    """
    群消息推送
    """
    def post(self):
        """
        """
        result = {
            "code": 1,
            "msg": "推送成功"
        }
        userid = self._xss(self.get_argument("userid", ""))
        message = self._xss(self.get_argument("message", ""))
        message = self._xss(self.get_argument("group", ""))
        if not userid or not message:
            result["code"] = 0
            result["msg"] = "参数不能为空"
        elif userid not in self.application._userOnlineStatusDicts:
            result["code"] = 4010
            result["msg"] = "用户不在线"
        else:
            logging.info(message)
            try:
                messageJson = json.loads(message)
                dataList = messageJson.get("dataList",[])
                for data in dataList:
                    self.application._userOnlineStatusDicts[userid].write_message(data)
            except:
                logging.error(traceback.format_exc())
        self.write(result)
        self.finish()
        return