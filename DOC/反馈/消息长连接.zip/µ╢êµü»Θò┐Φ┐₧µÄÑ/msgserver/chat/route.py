#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 长链接
  Created: 10/16/18
"""

from tornado.web import url
import chat.chat
import chat.message

connectRouter = [
    # 消息链接
    url(r'/message/connect', chat.chat.MessageHandler, name="message_connect"),
    # 消息断开
    url(r'/message/disconnect', chat.chat.DisconnectHandler, name="message_disconnect"),
    # 消息推送
    url(r'/message/push', chat.message.MsgUserpush, name="message_push"),
    # 多消息推送
    url(r'/message/pushlist', chat.message.MsgUserpushList, name="message_pushlist"),
]