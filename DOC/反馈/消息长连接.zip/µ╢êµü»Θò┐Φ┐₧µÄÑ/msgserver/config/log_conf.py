#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/9/12 上午9:42
# @Author  : qiuyan
# @Site    : 
# @File    : log_conf.py
# @Software: PyCharm


LOG_PATH=''