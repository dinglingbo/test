#!/usr/bin/env python
#coding:utf-8
"""
  Author:  
  Purpose: 多库连接配置文件
  Created: 06/29/17
"""
#======================用户数据===========================
# mysql连接配置:车辆数据库 （只读数据库）
mysql_config = {
    "user_r" : {
        "host" : "192.168.10.166", #数值类型：字符串
        "port" : 3306, #数值类型：整型
        "username" : "a", #数值类型：字符串
        "pwd" : "110", #数值类型：字符串
        "db" : "users", #选择使用的database, 数值类型：字符串
    },
}

# redis连接配置
redis_config = {
    "user": {
        "host" : "192.168.10.166", #数值类型：字符串
        "port" : 6379, #数值类型：整型
        "db" : 2, #选择使用的database, 数值类型：整型
        "retry" : 3, #重试次数,数值类型：整型
    },
}