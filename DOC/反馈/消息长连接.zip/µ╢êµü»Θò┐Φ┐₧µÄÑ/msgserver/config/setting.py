#!/usr/bin/env python
#coding:utf-8

_settings = {
    "cookie_secret": "p4Qy1mcwQJiSOAytobquL3YDYuXDkkcYobmUWsaBuoo",
    'xsrf_cookies': False,
    'debug': False,
    "gzip" : True
}

# 通知后端地址
rpc_host = "https://007vin.com"

# 以下是脚本配置
LOG_FILE = '/home/xmais/project/msgserver/log/'

message_url = 'http://127.0.0.1:6088/message/push'
online_url = 'http://127.0.0.1:6088//users/onlinelist'

new_user_key = 'message_user_push_007'


NOTIFY = 'notify'
FEEDBACK = 'feedbcak'
ADIMAGE = "adimage"
INVENTORY = "inventory"  # 5

message_type = {
    FEEDBACK: {
        'message_code': 80002,
        'title': '反馈回复提醒',
        'content': '',
        'inid': '',
        'fid': '',
        'msg_exist_time': 1800,
        'is_show': 1,
        'url': ""
    },
    NOTIFY: {
        'message_code': 80001,
        'title': '',
        'content': '',
        'msg_exist_time': 1800,
        'is_show': 0,
        'url': ""
    },
    INVENTORY: {
        'message_code': 80003,
        'title': '您有新的询价消息',
        'content': '',
        'inid': '',
        'msg_exist_time': 5,
        'is_show': 0,
        'url': ""
    }
}