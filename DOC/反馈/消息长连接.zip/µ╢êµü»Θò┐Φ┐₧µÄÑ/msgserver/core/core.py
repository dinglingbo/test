#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 装饰器模块
  Created: 09/03/18
"""
import logging
import time
import tornado
import base64
import json
import hashlib
import urllib
import traceback

# 项目模块
from .encrypt import authkey, decrypt_auth 
#from monitors.shield import monitored_urls
from monitors.shield import close_shield,IP_Whitelist

#极验验证
from geetest.geesdk_tools import check_geetest_page
    
# 前端页面请求接口权限校验-页面跳转
def with_current_user_take_out(func):
    """
    功能：用户页面权限校验需要跳转到其他页面
    """
    def wrapper(self):
        sTime = time.time()
        user_json = self.get_secure_cookie("Authorization")
        result = {}
        if user_json:
            user = tornado.escape.json_decode(user_json)
            getTime = tornado.escape.json_decode(self.get_secure_cookie("SessionId"))
            if getTime == self._rsdb.get("%s_expires" % user):
                real_ip = self.request.headers.get("X-Real-IP")
                if not real_ip:
                    real_ip = self.request.remote_ip
                logging.info("The real_ip %s, username %s, uri %s" % (real_ip, user, self.request.path))
                yc_id = self.check_yc_id(self.get_cookie("JSESSIONID"))                
                auth = self.get_argument("auth", "")
                if auth:
                    decytAuth = decrypt_auth(urllib.unquote(auth), authkey)
                    self.request.arguments["auth"] = [decytAuth]
                self.request.arguments["users"] = [user]
                func(self)
            else:
                self.redirect("/")
        else:
            self.redirect("/")
        logging.info("%s %s [%s] API time: %s" % (func.__name__.upper(), self.request.path, func.__module__, time.time() - sTime))
        return
    return wrapper  

#----------------------------------------------------------------------
def with_interface_time(func):
    """
    打印接口使用时间
    """
    def wrapper(self):
        sTime = time.time()
        func(self)
        logging.info("%s %s [%s] API time: %s" % (func.__name__.upper(), self.request.path, func.__module__, time.time() - sTime))
        return
    return wrapper    

#----------------------------------------------------------------------
def with_check_sessionid(func):
    """
    校验user是否存在与解析账号信息
    """
    def wrapper(self):
        result = {}
        user_json = self.get_secure_cookie("Authorization")
        if user_json: 
            getTime = tornado.escape.json_decode(self.get_secure_cookie("SessionId"))
            userTime = self._rsdb.get("%s_expires" % user)
            if getTime == userTime:
                return func(self)
            elif userTime and getTime < userTime:
            # 说明是被其他登录者挤掉
                result["code"] = 401
                result["msg"] = """你的账号在另一台设备上登录了零零汽。
如非本人操作，则密码可能已泄漏，建议立即前往零零汽个人中心-账户管理修改密码。"""
            else:
                result["code"] = 400
                result["msg"] = "cookie失效"
        else:
            result["code"] = 400
            result["msg"] = "未登录"
        self.write(result)
        self.finish()
        return
    return wrapper

#----------------------------------------------------------------------
def with_decrypt_auth(func):
    """
    解密Auth
    """
    def wrapper(self):
        auth = self.get_argument("auth", "")
        if auth:
            decytAuth = decrypt_auth(urllib.unquote(auth), authkey)
            self.request.arguments["auth"] = [decytAuth]
        return func(self)
    return wrapper

#----------------------------------------------------------------------
def with_monitor_interface(func):
    """
    1. 监控接口频率；
    2. 对请求超频接口，做验证；
    3. 对异常接口账号做封号处理
    """
    def wrapper(self):
        result = {}
        sTime = time.time()    
        url_path = self.request.path    # 当前请求接口
        #if url_path in monitored_urls:
            # 监控monitored_urls中的指定接口
        if not self.handel_monitored_path(yc_id ,url_path):
            # 接口监控不通过，返回-1000 通知前端开始验证码验证
            if check_geetest_page(self, yc_id):
                isCookie = False
                result["code"] = -1000
                self.write(result)
                self.finish()
            else:
                # 请求验证码页面过多，直接封号(封号操作会同时注销用户账户)
                self.closeuser(yc_id,remark="对接口[%s]访问频率超额，短时间内多次请求验证码页面"%url_path)
                close_shield(self, yc_id)
                self.redirect("/")  # 跳转至首页
                #result["code"] = 400
                #self.write(result)
                #self.finish()
            return
        else:
            return func(self)
    return wrapper

def with_role_genera(func):
    """ 权限校验总枢纽 """
    def role_check(self):
        yc_id = self.check_yc_id(self.get_cookie("JSESSIONID"))
        role_type,accessed = self.check_user_role_genera(yc_id)
        if not accessed:
            result = {
                "code": -999,
                "msg": "没有查询的权限，请购买%s使用权"%role_type,
                "title": role_type,
                "time": 0,
                "data" : [],
            }
            if self.check_role_status(role_type, yc_id):
                result['code'] = -998
                result['msg'] = "您购买的套餐已到期, 购买月卡或年卡即可继续查询"
            self.write(result)
            self.finish()
        else:
            func(self)
    return role_check

def with_brand_article(func):
    """ 品牌件权限校验 """
    def wrapper(self):
        yc_id = self.check_yc_id(self.get_cookie("JSESSIONID"))
        path = self.request.path
        if not self.check_user_brand_article(yc_id, path):
            result = {
                "code": -999,
                "msg": "没有查询的权限，请购品牌件使用权",
                "time": 0,
                "data" : [],
            }
            if self.check_role_status("品牌件", yc_id):
                result['code'] = -998
                result['msg'] = "您购买的套餐已到期, 购买月卡或年卡即可继续查询"
            self.write(result)
            self.finish()
        else:
            func(self)

    return wrapper




def pass_all_(func):
    def wrapper(*args, **kw):
        print('call %s():' % func.__name__)
        return func(*args, **kw)
    return wrapper



with_current_user_take_out=pass_all_
with_current_user=pass_all_
with_ppycars_user=pass_all_
with_auth_user=pass_all_
with_user_time=pass_all_
with_secret_auth=pass_all_
with_brand_article=pass_all_
with_role_genera=pass_all_
with_cars_role_user=pass_all_