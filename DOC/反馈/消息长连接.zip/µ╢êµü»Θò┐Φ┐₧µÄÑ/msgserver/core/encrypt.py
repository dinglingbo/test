#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 加密模块
  Created: 09/03/18
"""

import sys
try:
    if sys.version_info.major<3:
        from urllib import quote, unquote
    else:
        from urllib.parse import quote, unquote
except:
    pass
import base64
# 用于auth加密与解密
# 密钥
authkey = "ulei"
# 异或算法
xorStr = lambda ss,cc: ''.join(chr(ord(s)^ord(cc)) for s in ss)
# 方法
def encrypt_auth(data,key=authkey):
    """数据加密"""
    enStr = data   
    for cc in key:
        enStr = xorStr(enStr,cc)
    if isinstance(enStr, str):
        enStr = enStr.encode("utf-8")     
    return quote(base64.b64encode(enStr))

def decrypt_auth(data,key=authkey):
    """数据解密"""
    data = unquote(unquote(data))
    deStr = base64.b64decode(unquote(data))
    deKey = key[::-1]
    if isinstance(deStr, bytes):
        deStr = deStr.decode("utf-8")    
    for cc in deKey:
        deStr = xorStr(deStr,cc)
    return deStr
#g="{\"AE\": [\"TUE\", \"STV\", \"STH\", \"EDF\", \"KRS\", \"FAD\", \"GES\", \"AGM\", \"KAE\", \"GAB\", \"HIA\", \"AER\", \"SZU\", \"ZSS\", \"SAU\", \"ZFM\", \"BFA\", \"GKH\", \"BRS\", \"FRO\", \"AHV\", \"AKB\", \"TYP\", \"RER\", \"BRM\", \"BAH\", \"LRA\", \"LEN\", \"RAA\", \"ABR\", \"TGL\", \"BOW\", \"TWU\", \"VBK\", \"ATA\", \"KRM\", \"BAV\", \"GRD\", \"LSS\", \"CWV\", \"EBB\", \"STF\", \"KRB\", \"SWP\", \"FRI\", \"TDA\", \"ZBR\", \"ZKV\", \"SHM\", \"TRW\", \"DEI\", \"LBH\", \"LER\", \"KOV\", \"SIE\", \"TSV\", \"SZL\", \"BOB\", \"HIS\", \"HAL\", \"KOH\", \"DAR\", \"GPR\", \"SSR\", \"TAV\", \"SHA\", \"SIH\", \"SSL\", \"SDH\", \"WSS\", \"TKV\", \"SSH\", \"IRS\", \"BED\", \"BEH\", \"PBH\", \"RSV\", \"FEH\", \"MSL\", \"MSR\", \"GNF\", \"AIB\", \"KBO\", \"SAB\", \"HAK\", \"ZIE\", \"GRV\", \"KSA\", \"TRF\", \"HES\", \"LAC\", \"EIH\", \"HGD\", \"ASR\", \"ASL\", \"FEU\", \"MAS\", \"ZKS\", \"BBO\", \"KUG\", \"KZH\", \"HBV\", \"SAG\", \"VRH\", \"SHV\", \"KBB\", \"ZTD\", \"KZV\", \"ASE\", \"CDW\", \"EDW\", \"STD\", \"WSA\", \"AED\", \"RDK\", \"EIL\", \"ALS\", \"LOR\", \"PGK\", \"NAV\", \"CDR\", \"SLE\", \"BEL\", \"EPH\", \"RAO\", \"GEN\", \"HSW\", \"FLS\", \"ANT\", \"HEW\", \"SWS\", \"LWR\", \"LSE\", \"SBR\", \"GRA\", \"NEL\", \"WWA\", \"NES\", \"SWR\", \"SNH\", \"MKU\", \"TAA\", \"HKA\", \"VEF\", \"VRT\", \"AKA\", \"ASI\", \"STA\", \"RAU\", \"MRB\", \"ZUH\", \"SGK\", \"MFA\", \"BWD\", \"WAL\", \"BVK\", \"ATE\", \"VTV\", \"AUS\", \"FAF\", \"BLB\", \"TPL\", \"COC\", \"RAD\", \"MOT\", \"AAU\", \"FZS\", \"LAK\", \"DFV\", \"GSP\", \"REI\", \"BAT\", \"KAR\", \"LEA\", \"GKV\", \"SIB\", \"VOS\", \"KIS\", \"SFV\", \"WIV\", \"CHR\", \"KFK\", \"TVE\", \"GMO\", \"INS\", \"DFH\", \"AFH\", \"REL\", \"GRT\", \"FHW\", \"LFF\", \"FGS\"], \"G\": \"MLQ\", \"V1\": \"7A\", \"vin\": \"LSVAD2188A2485788\", \"CG\": \"BY\", \"MN\": \"70916\", \"M\": \"CFBA\", \"CS\": \"X8D\", \"year\": \"2010\", \"date\": \"20101004\", \"CR\": \"6E\", \"sa\": [\"0A2\", \"0AE\", \"0BC\", \"0EG\", \"0F2\", \"0FA\", \"0G7\", \"0GG\", \"0KA\", \"0L2\", \"0N5\", \"0P1\", \"0QK\", \"0RB\", \"0SM\", \"0TA\", \"0UA\", \"0YZ\", \"1AC\", \"1C2\", \"1D0\", \"1E1\", \"1EY\", \"1G1\", \"1H0\", \"1KX\", \"1ME\", \"1N1\", \"1NL\", \"1PA\", \"1Q0\", \"1S1\", \"1SB\", \"1T2\", \"1X0\", \"1Z0\", \"1ZP\", \"2B1\", \"2C1\", \"2D0\", \"2G1\", \"2JC\", \"2LB\", \"2UA\", \"2V1\", \"2W0\", \"2WA\", \"3B4\", \"3C7\", \"3CA\", \"3FE\", \"3GA\", \"3H0\", \"3J1\", \"3L1\", \"3LJ\", \"3M0\", \"3MF\", \"3NW\", \"3P1\", \"3Q6\", \"3S0\", \"3U0\", \"3Y0\", \"3YR\", \"3ZM\", \"4A0\", \"4B0\", \"4E2\", \"4GF\", \"4K3\", \"4KC\", \"4L2\", \"4LA\", \"4M5\", \"4P1\", \"4QV\", \"4R1\", \"4SJ\", \"4TB\", \"4U5\", \"4UE\", \"4W0\", \"4X1\", \"4Z1\", \"4ZF\", \"5A7\", \"5C0\", \"5D1\", \"5J0\", \"5K0\", \"5MB\", \"5N2\", \"5RQ\", \"5SL\", \"6A0\", \"6E3\", \"6EJ\", \"6FR\", \"6KJ\", \"6P5\", \"6PA\", \"6Q1\", \"6QA\", \"6R0\", \"6SC\", \"6U0\", \"6W7\", \"6XD\", \"7A0\", \"7AA\", \"7B0\", \"7E0\", \"7JY\", \"7K6\", \"7M1\", \"7N2\", \"7P5\", \"7PA\", \"7Q0\", \"7QA\", \"7R6\", \"7V3\", \"7X1\", \"8AG\", \"8GU\", \"8JS\", \"8K0\", \"8L4\", \"8M0\", \"8N4\", \"8Q0\", \"8RM\", \"8SA\", \"8T0\", \"8TC\", \"8W0\", \"8WB\", \"8X0\", \"8Y1\", \"8Z6\", \"9A0\", \"9AB\", \"9D0\", \"9F0\", \"9FB\", \"9GH\", \"9J0\", \"9JD\", \"9L0\", \"9M0\", \"9P1\", \"9Q1\", \"9T0\", \"9TC\", \"9U0\", \"9Y1\", \"9ZW\", \"A8M\", \"AZ0\", \"B0A\", \"B36\", \"C00\", \"CU4\", \"D16\", \"E0A\", \"F0A\", \"FB0\", \"G06\", \"G1C\", \"H4G\", \"J1L\", \"K8L\", \"L0L\", \"L50\", \"N5U\", \"PKF\", \"Q2J\", \"QA0\", \"QD2\", \"QG0\", \"QJ1\", \"QS0\", \"QV0\", \"TT3\", \"U4A\", \"UA2\", \"UG0\", \"V0A\", \"VC0\", \"VF0\", \"VK0\", \"VL0\"], \"carCommt\": {}}"
if __name__ == "__main__":
    # data = "featureIds: [1093, 2843, 3642, 4284, 4374,"
    import json
    aa = encrypt_auth(json.dumps({'cid':'163154_06H_0'}), 'benz')
    print(aa)
    bb = decrypt_auth('fCVkaGNiJT0nJSV6', 'vwag')
    print (bb)
    #print (repr(bb))