#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/9/12 上午10:56
# @Author  : qiuyan
# @Site    : 
# @File    : errors.py
# @Software: PyCharm


class CodeException(Exception):
    def __init__(self, str):
        self.str=str

    def __str__(self):
        return self.str