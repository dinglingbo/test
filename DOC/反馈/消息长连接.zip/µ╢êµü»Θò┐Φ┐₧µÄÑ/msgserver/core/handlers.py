#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: handlers
  Created: 09/06/18
"""
# 业务路由模块
from chat.route import connectRouter
from users.route import usersRouter

#----------------------------------------------------------------------
def handlers_loads():
    """路由"""
    handlers = []
    ## 首页 /user/*
    # 账号注册
    # 账号销毁
    # 长链接
    # 在线数接口
    # 消息推送
    # 接收消息
    handlers.extend(usersRouter)
    ## 长链接
    handlers.extend(connectRouter)
    return handlers