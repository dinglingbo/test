#encoding:utf-8
__author__ = 'qiuyan'

import logging,os,time,traceback
class Log(object):
    def __init__(self,logger,log_path=''):
        self.fileHandlerName = ''
        self.fileHandler = None
        self.loggerName = logger
        self.logger = logging.getLogger(logger)
        self.logger.setLevel(logging.DEBUG)
        self.formatter = logging.Formatter("==start==\ntime:%(asctime)s \nlogger:%(name)s \nlevel:%(levelname)s \nfile:%(filename)s \nfun:%(funcName)s \nlineno:%(lineno)d \npathname:%(pathname)s \nmessage:%(message)s==end==\n")
        self.info_formatter=logging.Formatter("[created||%(asctime)s];[file||%(filename)s];%(message)s")
        # 控制台
        # ch = logging.StreamHandler()
        # ch.setLevel(logging.DEBUG)
        # ch.setFormatter(self.formatter)
        # self.logger.addHandler(ch)

        if log_path:
            self.path = os.path.join(log_path+ '/log/' + self.loggerName + '/')
        else:
            self.path = os.path.join(os.path.abspath(os.path.dirname(__file__)), '../log/',self.loggerName+'/')

    def setfh(self):
        fname = time.strftime("%Y%m%d")
        if fname!=self.fileHandlerName:
            if self.fileHandler!=None :
                self.logger.removeHandler(self.fileHandler)
            path = self.path
            if os.path.isdir(path) == False:
                os.makedirs(path)
            fh = logging.FileHandler(path+fname+'.log')
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(self.formatter)
            self.logger.addHandler(fh)
            self.fileHandlerName = fname
            self.fileHandler = fh

    def set_infofh(self):
        fname = time.strftime("%Y%m%d")
        if fname != self.fileHandlerName:
            if self.fileHandler != None:
                self.logger.removeHandler(self.fileHandler)
            path = self.path
            if os.path.isdir(path) == False:
                os.makedirs(path)
            fh = logging.FileHandler(path + fname + '.log')
            fh.setLevel(logging.INFO)
            fh.setFormatter(self.info_formatter)
            self.logger.addHandler(fh)
            self.fileHandlerName = fname
            self.fileHandler = fh

    def _fmtInfo(self,msg):
        if len(msg)==0:
            msg = traceback.format_exc()
            return msg
        else:
            _tmp = [msg[0]]
            #python2 3处理空的问题
            if not traceback.format_exc() in ['None\n','NoneType: None\n']:
                _tmp.append(traceback.format_exc())
            return ''.join(_tmp)

    def debug(self,*msg):
        _info = self._fmtInfo(msg)
        try:
            self.setfh()
            self.logger.debug(_info)
        except:
            print('mylog debug:' + _info)

    def error(self,*msg):
        _info = self._fmtInfo(msg)
        try:
            self.setfh()
            self.logger.error(_info)
        except:
            print('mylog error:' + _info)

    def info(self,msg):
        _info = self._fmtInfo(msg)
        try:
            self.set_infofh()
            self.logger.info(_info)
        except:
            pass

    def warning(self,*msg):
        _info = self._fmtInfo(msg)
        try:
            self.setfh()
            self.logger.error(_info)
        except:
            pass

