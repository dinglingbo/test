#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<*_*>
  Purpose: 
  Created: 10/10/18
"""
import os
import re
import json
import hashlib
import traceback
import requests

import logging

from tornado.httpclient import AsyncHTTPClient
from tornado.httpclient import HTTPRequest
from tornado.web import RequestHandler
from tornado.websocket import WebSocketHandler

from lib.sqlHandlers import SqlHandlers
from config.setting import rpc_host

sqlHandler = SqlHandlers()

class BaseHandler(RequestHandler):

    #----------------------------------------------------------------------
    def __init__(self, application, request, **kwargs):
        """"""
        super(BaseHandler, self).__init__(application, request, **kwargs)
        self._sql = SqlHandlers()

    @property
    def _mdb(self):
        """"""
        return self.application.syncdb

    @property
    def _rsdb(self):
        return self.application._rdb

    #----------------------------------------------------------------------
    def updateUserMessage(self, yc_id, inid):
        """"""
        table_name = "user_information"
        keyDict = {
            "message_status" : 2,
            "message_time" : "now()",
        }
        kwargs = {
            "where" : [("yc_id", yc_id,"=", "and"), ("inid", inid,"=", "")]
        }
        sql = self._sql._update(table_name, keyDict, **kwargs)
        try:
            self._mdb.execute(sql) 
        except:
            logging.error(traceback.format_exc())
        

    def getMd5(self, data):
        """"""
        m = hashlib.md5()
        if isinstance(data, str):
            data = data.encode()
        m.update(data)
        return m.hexdigest()

    def unicode2utf8(self,data):
        """
        转换输入对象为utf8格式
        :param data:
        :return:
        """
        if isinstance(data, bytes):
            return data.decode('utf8')
        if isinstance(data, str):
            return data
        elif isinstance(data, collections.Mapping):
            return dict(map(self.unicode2utf8, data.items()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(self.unicode2utf8, data))
        else:
            return data
        
    #----------------------------------------------------------------------
    def utf8ToBytes(self, data):
        """"""
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode('utf8')
        elif isinstance(data, collections.Mapping):
            return dict(map(self.utf8ToBytes, data.items()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(self.utf8ToBytes, data))
        else:
            return data        

    def _xss(self,data):
        """
        防止xss注入
        """
        if data:
            getData = self.unicode2utf8(data)
            return data.replace(" ","")
        else:
            return ""
        
class BaseWebSocketHandler(WebSocketHandler):

    #----------------------------------------------------------------------
    def __init__(self, application, request, **kwargs):
        """"""
        super(BaseWebSocketHandler, self).__init__(application, request, **kwargs)
        self._sql = SqlHandlers()

    @property
    def _mdb(self):
        """"""
        return self.application.syncdb

    @property
    def _rsdb(self):
        return self.application._rdb

    #async def fetch_response(self,req):
        #"""
        #远程rpc接口异步调用
        #"""
        #response = ""
        #try:
            #response = await AsyncHTTPClient().fetch(req)
            ##response = resp.body
        #except Exception as ex:
            #except_args = ex.args
            #except_type = type(ex).__name__
            #template = "An exception of type {0} occurred. Arguments:\n{1!r}"
            #message = template.format(except_type, except_args)
            #logging.debug("-----------%s"%message)
        #finally:
            #return response
        
    #----------------------------------------------------------------------
    def notice_process_msg(self, yc_id, status):
        """
        通知web后端用户登录或者退出了
        yc_id用户账号
        status：login表示登录信息，logout表示登出信息
        """
        if rpc_host == "":
            return
        if status == "login":
            rpc_url = rpc_host + "/message/push/login"
        elif status == "logout":
            rpc_url = rpc_host + "/message/push/logout"
        else:
            return
        try:
            url = "%s?yc_id=%s" % (rpc_url, yc_id)
            req = requests.get(url,timeout=1)
            print(req.content)
        except:
            logging.error(traceback.format_exc())
        return
        

    def getMd5(self, data):
        """"""
        m = hashlib.md5()
        if isinstance(data, str):
            data = data.encode()
        m.update(data)
        return m.hexdigest()

    def unicode2utf8(self,data):
        """
        转换输入对象为utf8格式
        :param data:
        :return:
        """
        if isinstance(data, bytes):
            return data.decode('utf8')
        if isinstance(data, str):
            return data
        elif isinstance(data, collections.Mapping):
            return dict(map(self.unicode2utf8, data.items()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(self.unicode2utf8, data))
        else:
            return data
        
    #----------------------------------------------------------------------
    def utf8ToBytes(self, data):
        """"""
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode('utf8')
        elif isinstance(data, collections.Mapping):
            return dict(map(self.utf8ToBytes, data.items()))
        elif isinstance(data, collections.Iterable):
            return type(data)(map(self.utf8ToBytes, data))
        else:
            return data        

    def _xss(self,data):
        """
        防止xss注入
        """
        if data:
            getData = self.unicode2utf8(data)
            return data.replace(" ","")
        else:
            return ""