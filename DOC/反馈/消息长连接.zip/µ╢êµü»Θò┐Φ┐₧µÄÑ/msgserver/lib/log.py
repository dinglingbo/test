#!/usr/bin/env python
#coding:utf-8
##############################################################################
# FileName: log.py
# Description: 日志模块
# Version: V1.0
# Author: xulei
# Function List:
#   1. 处理多进程写入日志的问题 
#   2. 日志按天进行分割
#   3. 设置日志格式
# History:
#	<author>		<time>		<version>		<desc>
#	xulei		     2017/12/11	           V1.0			创建文件
#       xulei                2017/12/12            V1.1                 修复tornado等级设置的问题
###############################################################################
from tornado import options

import logging, logging.handlers
import configparser
from sys import stdout
from .safeFileHandler import SafeFileHandler

# 装载配置文件
conf = configparser.ConfigParser()
conf.read("config/config.conf", encoding='utf-8')

logger = None
handler = None

def initLog():
    global logger, handler
    logger = logging.getLogger()
    getDebug = conf.get("logs","logging")
    # 设置日志等级-设置tornado
    options.options.logging = getDebug
    log_file = conf.get("logs","log_file_prefix")
    try:
        log_ways = conf.get("logs","log_ways")
    except:
        log_ways = "day"
    handler = SafeFileHandler(log_file, "a", log_ways, encoding='utf-8')
    # 设置日志格式
    formatStr = '[%(asctime)s][%(filename)s][%(funcName)s][Line:%(lineno)d]:%(message)s'
    handler.setFormatter(logging.Formatter(formatStr))
    logger.addHandler(handler)
    
initLog()