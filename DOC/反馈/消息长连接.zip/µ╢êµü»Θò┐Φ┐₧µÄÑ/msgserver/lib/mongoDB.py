#!/usr/bin/python
# -*- coding: utf-8 -*-
import logging
from pymongo import MongoClient
import traceback


def getMongoConn(m_conf):
    """
    获取mongo链接
    """
    logging.info("-->begin:getMongoConn,host[%(host)s],port[%(port)d],database[%(dbname)s]"%m_conf)
    db_obj=None
    i=0
    while i<m_conf.get("retry",3):
        try:
            conn = MongoClient(m_conf["host"],m_conf["port"])
            db_obj = conn.get_database(name=m_conf["dbname"])
            db_obj.authenticate(m_conf["user"],m_conf["pwd"]) #用户认证
            if db_obj:
                break
            else:
                logging.info("----------MongoConn Failed Retrying --------")
        except:
            logging.error(traceback.format_exc())
        i += 1
    return db_obj