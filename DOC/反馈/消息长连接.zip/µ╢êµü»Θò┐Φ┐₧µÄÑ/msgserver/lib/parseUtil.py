#!/usr/bin/env python
# encoding: utf-8
'''
@author: qiuyan
@contact: winston@peipeiyun.com
@file: parseUtil.py
@time: 2018/10/8 下午6:18
@desc:
'''

import configparser

class ConfigParser(object):
    """配置解析器"""

    @classmethod
    def get_parser(cls, filename):
        """获得文件解析对象"""
        parser = configparser.ConfigParser()
        parser.read(filename)
        return parser
