#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: mysql数据重组
  Created: 07/11/16
"""

import re
import logging

########################################################################
class SqlHandlers():
    """以参数的形式重组sql"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        __ulei__ = "xulei"

    #----------------------------------------------------------------------
    def _setDb(self, db):
        """"""
        self.db = db

    #----------------------------------------------------------------------
    def _select(self, table_name, keyList, **kwargs):
        """
        table_name: 表名
        keyList: 查询字段列表
        kwargs: 条件参数

        """
        keys = ",".join(keyList)
        sql = "select %s from %s" % (keys, table_name)
        #print sql
        getSql = self.__buildSql(sql, **kwargs)
        #print getSql
        getSql = self.__sqlfix(getSql)
        logging.info(repr(getSql))
        return getSql

    #----------------------------------------------------------------------
    def _insert(self, table_name, keyDict, **kwargs):
        """
        table_name: 表名
        keyDict: 参数字典
        kwargs: 条件参数
        """
        keys = ",".join(keyDict.keys())
        valueList = []
        for value in keyDict.values():
            if (type(value) == type("string") or type(value) == type(u"unicode")) and value != "now()":
                valueList.append("'%s'" % value.replace("'","''"))
            else:
                valueList.append(str(value))
        values = ",".join(valueList)
        sql = "insert into %s (%s) values (%s)" % (table_name, keys, values)
        if "duplicate" in kwargs:
            sql += " on duplicate key update "
            vList = []
            for k in kwargs["duplicate"]:
                vList.append("`%s`=values(`%s`)" % (k, k))
            sql += ",".join(vList)          
        #print sql
        sql = self.__sqlfix(sql)
        #print sql
        return sql

    #----------------------------------------------------------------------
    def _update(self, table_name, keyDict, **kwargs):
        """
        更新语句重组
        table_name: 表名
        keyDict: 参数字典
        kwargs: 条件参数
        """
        setList = self._setUpdateParam(keyDict)
        if not setList:
            return None
        setData = ",".join(setList)
        sql = "update %s set %s" % (table_name, setData)
        getSql = self.__buildSql(sql, **kwargs)
        #print getSql
        getSql = self.__sqlfix(getSql)
        logging.info(getSql)
        return getSql        

    #----------------------------------------------------------------------
    def _delete(self):
        """删除语句重组"""
        pass

    #----------------------------------------------------------------------
    def _setUpdateParam(self, keyDict):
        """"""
        paramList = []
        for key,value in keyDict.items():
            if type(value) in [int, float] or value in ["now()", "NOW()"]:
                data = "%s=%s" % (key, value)
            else:
                data = "%s='%s'" % (key, value.replace("'","\\'"))
            paramList.append(data)
        return paramList

    def __sqlfix(self, sql):
        """
        转义特殊字符
        """
        sql = re.sub(r"(?<!%)%(?!%)", "%%", sql)
        #sql = re.sub(r"(?<!')'(?!')", r"''", sql)
        sql = re.sub(r"(?<!\\)\\(?!\\)", r"\\\\", sql)
        return sql

    #----------------------------------------------------------------------
    def __where(self, params):
        """
        where条件:
        params: [(key, value, way, mode),(key, value, way, mode),...]
        way: "=", "!=", "like"
        mode: "and", "or"
        """
        setWhere = ""
        whereList = ["where"]
        for param in params:
            key, value, way, mode = param
            if type(value) == str:
                value = value.replace("'","''")
            if way == "like":
                data = "`%s` %s '%%%%%s%%%%'" % (key, way, value)
            elif way == "in":
                data = "`%s` %s %s" % (key, way, str(value))
            else:
                if type(value) == int:
                    data = "`%s` %s %d" % (key, way, value)
                elif value.lower() == "now()":
                    data = "`%s` %s %s" % (key, way, value)
                else:
                    data = "`%s` %s '%s'" % (key, way, value)
            if mode:
                data += " %s" % mode
            whereList.append(data)
        setWhere = " ".join(whereList)
        return setWhere

    #----------------------------------------------------------------------
    def __order(self, params):
        """
        降序与升序
        params: [(key, desc), (kes2, asc)...]
        key: 表示数据库字段
        """
        setList = []
        for param in params:
            setList.append(" ".join(param))
        return ",".join(setList)

    #----------------------------------------------------------------------
    def __buildSql(self, sql, **kwargs):
        """
        {
           "where":__where,
           "limit": "__limit",
           "order": "__order",
           "group": "__group",
           "having": "__having",
        }
        """
        if "where" in kwargs:
            sql = "%s %s" % (sql , self.__where(kwargs["where"]))
        if "order" in kwargs:
            order = "order by %s" % self.__order(kwargs["order"])
            sql = "%s %s" % (sql, order)
        if "limit" in kwargs:
            limits = "limit %d, %d" % kwargs["limit"]
            sql = "%s %s" % (sql, limits)        
        return sql

    #----------------------------------------------------------------------
    def execute(self, sql):
        """"""
        result = self.db.execute(sql)
        return result

    #----------------------------------------------------------------------
    def get(self, sql):
        """"""
        return self.db.get(sql)

if __name__ == '__main__':
    task = SqlHandlers()
    condition = {
        "where":[("username", "test", "=", "and"), ("pwd", "123%4\\5'6", "like", "")],
        "limit":(0,1),
        "order":[("phone", "desc"), ("email", "asc")]
    }
    task._select("user", ["username", "pwd"], **condition)
    keyDict = {
        "username" : "sss",
        "password" : "ss",
        "encrypt_pwd" : "ss",
        "first_name" : "ss",
        "last_name" : "ss",
        "avatar_url" : "ss",
        "register_datetime" : "now()",
        "country" : "ss",
        "country_code" : "ss",
        "city" : "",
        "phone" : "",
        "last_login_datetime" : "now()",
        "email" : ""
    }
    task._insert("user", keyDict)