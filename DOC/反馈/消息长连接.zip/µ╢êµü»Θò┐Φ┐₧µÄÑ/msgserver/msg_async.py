#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 1. 处理群发消息，
           2. 处理离线消息
  Created: 11/06/18
"""

import logging
import time
import json
import traceback
import os
import sys
import redis
import requests
import threading

from copy import deepcopy

# 数据库模块
from lib.torndb import get_mdbconn
from lib.redisdbs import getRedisConn
from lib.sqlHandlers import SqlHandlers

from config.mdb_config import (mysql_config, redis_config) 
from config.setting import *

########################################################################
class MsgServer(object):
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self._sql = SqlHandlers()
        self._mdb = get_mdbconn(mysql_config["user_r"])
        self._rdb = getRedisConn(redis_config["user"])
        #self.dates = time.strftime("%H", time.localtime())
        self.dates = ["08","10","12","14","16","18","20","22"]
        self.push_history = []

    #----------------------------------------------------------------------
    def push_ad_message(self, user_id):
        """推送浮层广告"""
        tableName = "ad_image"
        keyList = ["aid", "url", "img", "content"]
        kwargs = {
            "where" : [("status", 1, "=", "and"),("start_time", "now()", "<", "and"),("end_time", "now()", ">", "")],
            "order" : [("sort", "asc")]
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        print(sql)
        result = self._mdb.query(sql)
        aidList = []
        for aidData in result:
            aidList.append(str(aidData.get("aid")))
        if not aidList:
            return
        pushList = self.select_user_information_common_push(user_id, tuple(aidList))
        if not pushList:
            return
        resultJson =     {
            "message_code":80004, # 消息类型
            "msg_exist_time":-1, # 消息显示时间，单位秒,-1表示不自动关闭
            "type":"all",
            "data" : []
        }
        msgTmp = {
            "title" : "", # 标题，备用字段后续可能使用
            "content" : "", # 消息内容，备用字段后续可能使用
            "pic_url" : "", # 广告图片地址
            "url":"",  # 是否需要跳转或者打开新窗口，没有则为空,
            'index': 0 # 图片顺序（从0开始)
        }
        index = 0
        for res in result:
            if str(res.get("aid")) in pushList:
                msgData = deepcopy(msgTmp)
                msgData["pic_url"] = res.get("img")
                msgData["url"] = res.get("url")
                msgData["index"] = index
                index += 1
                resultJson["data"].append(msgData)
                self.insert_user_information_common_push(user_id, str(res.get("aid")))
        self.push_user_message(resultJson, user_id)

    #----------------------------------------------------------------------
    def push_user_message(self, data, user_id):
        """"""
        dataDict = {
            "userid" : user_id,
            "type" : "json",
            "message" : json.dumps(data)
        }
        r = requests.post(message_url, data=dataDict, timeout=2)
        print(r.content)

    #----------------------------------------------------------------------
    def insert_user_information_common_push(self, user_id, inid):
        """推送消息，插入推送记录"""
        tableName = "user_information_common_push"
        keyDict = {
            "inid" : inid,
            "yc_id" : user_id,
            "push_datetime" : "now()"
        }
        sql = self._sql._insert(tableName, keyDict)
        print(sql)
        try:
            self._mdb.execute(sql)
        except:
            print(traceback.format_exc())

    #----------------------------------------------------------------------
    def select_user_information_common_push(self, user_id, aidTuble):
        """"""
        tableName = "user_information_common_push"
        keyList = ["inid"]
        kwargs = {
            "where" : [("yc_id", user_id, "=", "and")]
        }
        if len(aidTuble) == 1:
            kwargs["where"].append(("inid", aidTuble[0], "=", ""))
        else:
            kwargs["where"].append(("inid", aidTuble, "in", ""))
        sql = self._sql._select(tableName, keyList, **kwargs)
        print(sql)
        result = self._mdb.query(sql)  
        aidList = list(aidTuble)
        for res in result:
            aidList.remove(res.get("inid"))
        return aidList
    
    #----------------------------------------------------------------------
    def group_user_message(self, user_id):
        """群消息离线推送"""
        tableName = "user_information_common"
        keyList = ["inid", "title", "text"]
        kwargs = {
            "where" : [("push_status", 1, "=", "and"),("valid_datetime", "now()", ">", "")],
            "order" : [("register_datetime", "asc")],
            "limit" : (0, 1)
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        print(sql)
        result = self._mdb.get(sql) 
        if not result:
            return
        inidList = [result.get("inid")]
        pushList = self.select_user_information_common_push(user_id, tuple(inidList))
        if not pushList:
            return
        msgTmp = {
            'message_code': 80001,
            'title': result.get("title"),
            'content': result.get("text"),
            'msg_exist_time': 1800,
            'is_show': 0,
            'url': "",
            "inid": result.get("inid"),
            "type":"all"
        }
        self.insert_user_information_common_push(user_id, result.get("inid"))
        self.push_user_message(msgTmp, user_id)
        
    #----------------------------------------------------------------------
    def get_online_users(self):
        """获取在线用户"""
        try:
            r = requests.get(online_url)
            content = r.content
            try:
                dataJson = json.loads(content)
            except:
                dataJson = eval(content)
            return dataJson.get("data",[])
        except:
            print(traceback.format_exc())
            return []
        
    #----------------------------------------------------------------------
    def push_all_message(self, dataDict):
        """推送在线用户群发消息"""
        try:
            message = dataDict.get("message")
            msgJson = json.loads(message)
        except:
            print(traceback.format_exc())
            return
        usersList = self.get_online_users()
        for users in usersList:
            try:
                msgDict = deepcopy(msgJson)
                msgDict["userid"] = users.get("userid")
                r = requests.post(message_url, data=msgDict, timeout=2)
                print(r.content)
            except:
                print(traceback.format_exc())
    
    #----------------------------------------------------------------------
    def route_push_message(self, data):
        """消息推送路由"""
        try:
            dataJson = json.loads(data)
        except:
            dataJson = eval(data)
        user_id = dataJson.get("userid", "") 
        if not user_id:
            return
        elif user_id == "all":
            self.push_all_message(dataJson)
        else:
            if time.strftime("%H", time.localtime()) != self.dates:
                # 隔天清理用户推送缓存
                self.dates = deepcopy(time.strftime("%H", time.localtime()))
                del self.push_history
                self.push_history = []
            if user_id in self.push_history:
                return
            self.push_history.append(user_id)
            self.push_ad_message(user_id)
            self.group_user_message(user_id)
            
    def main_args(self, user_records="message_user_push_007"):
        """
        主函数入口
        """
        print("Starting ...")
        while 1:
            try:
                getTask = self._rdb.brpop(user_records, timeout=1)
                taskNum = self._rdb.llen(user_records)
                if getTask:
                    print("--> %s, -->taskNum>> %d, threadNum is %s" % (getTask[1],taskNum,1))
                    self.route_push_message(getTask[1])
                else:
                    time.sleep(1)
            except:
                print(traceback.format_exc())
                time.sleep(1)

def show_help():
    __args__     = "运行模式 功能参数"
    print("命令用法:\n    %s %s \n" % (os.path.basename(sys.argv[0]), __args__))
    print("参数说明:")
    print("   运行模式")
    print("        message [redis_key]:")
    print("   例子")
    print("        python sync_user_record.py message message_user_push_007 ")
    print("        ")
    return
                
if __name__ == '__main__':
    if len(sys.argv) < 2:
        show_help()
        sys.exit(0)  
    if sys.argv[1] == "message":
        task = MsgServer()
        threading.Thread(target=task.main_args, args=("message_user_push_007",)).start()    
    else:
        show_help()
        sys.exit(0)