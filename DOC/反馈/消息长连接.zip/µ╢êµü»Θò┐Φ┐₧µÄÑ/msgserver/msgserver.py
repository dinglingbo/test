#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 服务入口
  Created: 08/31/18
"""
import logging
import os
import configparser

# tornado模块
import tornado
import tornado.web
from tornado import httpserver, ioloop
from tornado.options import define, options

#日志服务-需要通过config/config.conf配置
from lib.log import initLog

#路由
from core.handlers import handlers_loads

# 数据库模块
from lib.torndb import get_mdbconn
from lib.redisdbs import getRedisConn


#配置文件
from config.mdb_config import (redis_config, mysql_config)
from config.setting import _settings

# 设置默认端口
define("port", default=6088, type=str)

#
root_path = os.path.abspath(os.curdir)

class Application(tornado.web.Application):
    def __init__(self, **overrides):       
        
        tornado.web.Application.__init__(self, handlers_loads(), **_settings)
        # 数据库配置
        self.syncdb = get_mdbconn(mysql_config["user_r"])
        self._rdb = getRedisConn(redis_config["user"])
        
        # 用来存放在线用户的容器
        self._userOnlineStatusDicts = {}

def main():
    #parser = configparser.ConfigParser()
    #for root,d,files in os.walk('conf'):
        #for file in files:
            #filename =os.path.join(root_path,root,file)
            #parser.read(filename)
    app = Application()
    #define("parser", default=parser, type=object)
    server = httpserver.HTTPServer(app)
    options.parse_command_line()
    server.listen(options.port, address="0.0.0.0")
    print("start success,the port is [%s]" % options.port)
    #print(options.parser.get('log_conf','path'))
    ioloop.IOLoop.instance().start()

if __name__ == '__main__':
    main()
    
    
