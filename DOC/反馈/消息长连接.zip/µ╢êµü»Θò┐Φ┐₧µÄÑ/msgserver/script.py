#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 脚本服务
      1. 初始零零汽平台账号注册
      2. 发送临时消息
  Created: 11/01/18
"""
import traceback

#----------------------------------------------------------------------
def regeistUsers():
    """"""
    # 数据库模块
    from lib.torndb import get_mdbconn
    
    #配置文件
    from config.mdb_config import mysql_config
    syncdb = get_mdbconn(mysql_config["user_r"])
    sqlParam = "select yc_id from user where `register_datetime` > '2018-11-03 20:30:58' limit %d, %d"
    n = 0
    m = 1000
    while True:
        sql = sqlParam % (n, m)
        print(sql)
        dataList = syncdb.query(sql)
        for data in dataList:
            insert_sql = "INSERT INTO `msg_users` (`userid`, `register_datetime`, `updatetime`, `status`, `platform`, `comment`) VALUES ('%s', now(), now(), 1, 'llq', '');" % data.get("yc_id")
            try:
                syncdb.execute(insert_sql)
                log_sql = "INSERT INTO `msg_users_online_log` (`userid`, `updatetime`, `online`) VALUES ('%s', now(), 0);" % data.get("yc_id")
                syncdb.execute(log_sql)
            except:
                print(traceback.format_exc())
        if len(dataList) != 1000:
            break
        n += 1000

if __name__ == '__main__':
    regeistUsers()