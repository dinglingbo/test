#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 脚本配置文件
  Created: 11/20/18
"""

import os

userIdPath = "/Users/12345/2018/msgServer/scripts/userid.txt"

message_url = 'http://127.0.0.1:5022/message/push'
online_url = 'http://127.0.0.1:5022//users/onlinelist'

data = {
        "inid": "1234567890", # 消息id
        "message_code":80001, # 消息类型
        "msg_exist_time":1800, # 消息显示时间，单位秒,默认是30分钟
        "title" : "系统消息", # 标题
        "content" : "为方便各位的使用，微信机器人在「车架号查询」页面新增了操作入口，请知晓。", # 消息内容
        "is_show" : 0, # 是否有查看详情
        "url":"",  # 是否需要跳转，没有则为空
    }