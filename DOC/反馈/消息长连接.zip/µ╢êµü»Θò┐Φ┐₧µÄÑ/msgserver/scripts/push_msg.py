#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 1. 推送消息，给特定用户推送消息
           2. 适用少量用户推送
  Created: 11/20/18
"""
import time
import requests
import json
import traceback
from copy import deepcopy

from conf import message_url, online_url, data, userIdPath

def push_user_message(data, user_id):
    """"""
    dataDict = {
        "userid" : user_id,
        "type" : "json",
        "message" : json.dumps(data)
    }
    r = requests.post(message_url, data=dataDict, timeout=2)
    print(r.content)
    return r.content

#----------------------------------------------------------------------
def byteToStr(data):
    """"""
    if type(data) == bytes:
        data = data.decode("utf-8")    
    return data

#----------------------------------------------------------------------
def main():
    """"""
    hours = time.strftime("%H", time.localtime())
    while int(hours) > 9:
        with open(userIdPath, "r") as fb:
            userIdData = fb.read()
        if not userIdData:
            break
        userIdData = byteToStr(userIdData)
        userIdList = userIdData.split("\n")
        cacheList = deepcopy(userIdList)
        for userId in userIdList:
            if not userId:
                continue
            userId = userId.replace("\r", "")
            try:
                content = push_user_message(data, userId)
                content = byteToStr(content)
                jsonData = json.loads(content)
                if jsonData["code"] == 1:
                    cacheList.remove(userId)
            except:
                print(traceback.format_exc())
            time.sleep(1)
        setData = "\n".join(cacheList)
        with open(userIdPath, "w") as fb:
            fb.write(setData)  
        time.sleep(3600)
        hours = time.strftime("%H", time.localtime())

if __name__ == '__main__':
    main()