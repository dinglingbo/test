#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 长链接
  Created: 10/16/18
"""

from tornado.web import url
import users.users

usersRouter = [
    url(r'/users/regiester', users.users.MsgUserRegiester, name="users_regiester"),
    url(r'/users/destroy', users.users.MsgUserDestroy, name="users_destroy"),
    url(r'/users/onlinelist', users.users.MsgUserOnlineCount, name="users_onlinelist"),
]