#!/usr/bin/env python
#coding:utf-8
"""
  Author:  xulei --<>
  Purpose: 1. 账号注册
           2. 账号注销
           3. 账号分类
           4. 账号在线数
  Created: 10/16/18
"""

import logging
import datetime

from lib.base import BaseHandler

class MsgUserRegiester(BaseHandler):
    """
    消息账号注册
    """
    def post(self):
        """
        注册信息提交
        """
        result = {
            "code": 1,
            "msg": "注册成功"
        }

        userid = self._xss(self.get_argument("userid", ""))  #
        platform = self._xss(self.get_argument("platform", ""))
        comment = self._xss(self.get_argument("comment", ""))

        if not userid:
            result["code"] = 0
            result["msg"] = "参数不能为空"
            self.write(result)
            self.finish()
            return
        if self.check_user(userid):
            result["code"] = 0
            result["msg"] = "用户已经注册"
            self.write(result)
            self.finish()
            return
        
        self.insert_user(userid, platform, comment)
        self.insert_log(userid)
        
        self.write(result)
        self.finish()
        return
    
    #----------------------------------------------------------------------
    def insert_user(self, userid, platform, comment):
        """注册账号"""
        tableName = "msg_users"
        keyDict = {
            "userid" : userid,
            "register_datetime" : "now()",
            "updatetime" : "now()",
            "status" : 1,
            "platform" : platform,
            "comment" : comment
        }
        kwargs = {
            "duplicate" : ["updatetime","status"]
        }
        sql = self._sql._insert(tableName, keyDict, **kwargs)
        self._mdb.execute(sql)
    
    #----------------------------------------------------------------------
    def insert_log(self, userid):
        """写入在线日志"""
        tableName = "msg_users_online_log"
        keyDict = {
            "userid" : userid,
            "updatetime" : "now()",
            "online" : 0
        }
        kwargs = {
            "duplicate" : ["updatetime","online"]
        }
        sql = self._sql._insert(tableName, keyDict, **kwargs)
        self._mdb.execute(sql)        
    
    #----------------------------------------------------------------------
    def check_user(self, userid):
        """判断用户是否存在"""
        tableName = "msg_users"
        keyList = ["userid"]
        kwargs = {
            "where" : [("userid", userid, "=", "and"),("status", 1, "=", "")]
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        logging.debug(sql)
        result = self._mdb.get(sql)
        if result:
            return True
        else:
            return False        


class MsgUserDestroy(BaseHandler):
    """
    消息账号销毁
    """
    def get(self):
        """
        注册信息提交
        """
        result = {
            "code": 1,
            "msg": "销毁成功"
        }

        userid = self._xss(self.get_argument("userid", ""))

        if not userid:
            result["code"] = 0
            result["msg"] = "参数不能为空"
            self.write(result)
            self.finish()
            return
        if not self.check_user(userid):
            result["code"] = 0
            result["msg"] = "用户未注册"
            self.write(result)
            self.finish()
            return
        
        self.update_user(userid)
        
        self.write(result)
        self.finish()
        return
    
    #----------------------------------------------------------------------
    def update_user(self, userid):
        """销毁账号"""
        tableName = "msg_users"
        keyDict = {
            "updatetime" : "now()",
            "status" : 0,
        }
        kwargs = {
            "where" : [("userid", userid,"=", "")]
        }
        sql = self._sql._update(tableName, keyDict, **kwargs)
        self._mdb.execute(sql)      
    
    #----------------------------------------------------------------------
    def check_user(self, userid):
        """判断用户是否存在"""
        tableName = "msg_users"
        keyList = ["userid"]
        kwargs = {
            "where" : [("userid", userid, "=", "and"),("status", 1, "=", "")]
        }
        sql = self._sql._select(tableName, keyList, **kwargs)
        logging.debug(sql)
        result = self._mdb.get(sql)
        if result:
            return True
        else:
            return False
        
class MsgUserOnlineCount(BaseHandler):
    """
    账号在线数量
    """
    def get(self):
        """
        注册信息提交
        """
        result = {
            "code": 1,
            "msg": "成功",
            "nowdate" : datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total" : 0,
            "data" : []
        }
        tableName = "msg_users_online_log"
        keyList = ["userid","updatetime"]
        kwargs = {
            "where" : [("online", 1, "=", "")]
        }        
        sql = self._sql._select(tableName, keyList, **kwargs)
        usersList = self._mdb.query(sql)
        for users in usersList:
            setUser  = {
                "userid" : users["userid"],
                "starttime" : str(users["updatetime"]),
            }
            result["total"] += 1
            result["data"].append(setUser)
        
        self.write(result)
        self.finish()
        return