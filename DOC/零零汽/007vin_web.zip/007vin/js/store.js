// 定义全局数据
define(function() {
  'use strict';
  return {
    search: null,
    carInfo: null,
    carAttrGroup: null,
    carAttrSubgroup: null,
    carPartsText: null,
    carPartsImg: null
  }
})